package com.mrli.dboperator;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.mrli.interfaces.IColumns;
/**
 * ���ݿ�����ļ���
 * @author MrLi
 *
 */
public class JDBCOperator {

	private final String DRIVERNAME = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
	private final String URL = "jdbc:sqlserver://localhost:1433;"
				+ " databaseName=mysql;user=sa;password=123456";
	private final String USERNAME = "sa";
	private final String PASSWORD = "123456";
	public String sqlStatement = new String();
	public Connection conn;
	public Statement stat;
	
	/**
	 * ������������
	 */
	public void LoadDriver(){
		try {
			Class.forName(DRIVERNAME);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}
	/**
	 * ��ȡ���ݿ�����
	 */
	public void getConnection(){
		try {
			this.conn = DriverManager.getConnection(URL, USERNAME, PASSWORD);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	/**
	 * ����һ��Statementʵ��
	 */
	public void createStatementObject(){
		try {
			this.stat = conn.createStatement();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	/**
	 * ִ�и��²���
	 */
	public int executeUpdate(){
		int result = 0;
		try {
			result = stat.executeUpdate(sqlStatement);
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			System.out.println("SQL: " + sqlStatement + " \r\n"
							+ " answer --------- " + result);
			/**
			 * ��֤ÿ�����ִ��һ��
			 */
			sqlStatement = null;
		}
		return result;
	}
	/**
	 * ִ�в�ѯ����
	 */
	public ResultSet executeQuery(){
		ResultSet result = null;
		try {
			result = stat.executeQuery(this.sqlStatement);
		} catch (SQLException e) {
			e.printStackTrace();
		} finally{
			System.out.println("SQL: " + this.sqlStatement + " \r\n"
							+ " answer --------- " + result);
			/**
			 * ��֤ÿ�����ִ��һ��
			 */
			this.sqlStatement = null;
		}
		return result;
	}
	/**
	 * �ر����ݿ�
	 */
	public void close(){
		try {
			stat.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	

	/**************************************************************************
	 * �����ݿ�Ĳ���
	 *************************************************************************/
	
	/**
	 * �������ݱ�
	 * @param myDataBasenamse ���ݱ�������
	 * @param object ����ÿһ��
	 */
	public void constructSQLStatement_createTable(IColumns object){
		this.sqlStatement = "use mysql create table " 
							+ object.toTableName() 
							+ " ( " + object.toAttributes() + " )";
	}
	/**
	 * ɾ��ָ����
	 * @param myDataBaseName ɾ���ı�������
	 */
	public void constructSQLStatement_dropTable(IColumns object) {
		this.sqlStatement = "use mysql drop table " + object.toTableName();
	}
	/**
	 * �����ݱ�����������
	 */
	public void constructSQLStatement_insertOneRow(IColumns object){
		this.sqlStatement = "use mysql insert into " 
							+ object.toTableName() + "( "
							+ object.toName() + " )"
							+ " values( "
							+ object.toValue()
							+ " )";
	}
	/**
	 * �����ݱ���ɾ������
	 * @param object
	 */
	public void constructSQLStatement_deleteOneRow(IColumns object){
			this.sqlStatement = "use mysql delete from "
								+ object.toTableName() + " " 
								+ " where "
								+ object.toPrimaryKeyName()
								+ " = "
								+ object.toPrimaryKeyValue() 
								+ " ; "
								;
	}
	/**
	 * �ڱ��в�ѯ����
	 * @param object
	 */
	public void constructSQLStatement_selectOneRow( IColumns object){
			this.sqlStatement = "use mysql select "
								+ object.toName()
								+ " from "
								+ object.toTableName() + " " 
								+ " where "
								+ object.toPrimaryKeyName()
								+ " = "
								+ object.toPrimaryKeyValue()
								+ " ; "
								;
	}
}
