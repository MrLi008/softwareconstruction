package com.mrli.objects;

import com.mrli.interfaces.IColumns;

/**
 * �����û���½����Ҫ����Ϣ
 * @author MrLi
 *
 */
public class UserLogData implements IColumns{

	private String userName;
	private String userPassword;
	private String userPasswordTip;

	public UserLogData() {
		this("userName", "123456", "Ĭ���û���");
	}
	public UserLogData(String userName, String userPassword,
			String userPasswordTip) {
		this.userName = userName;
		this.userPassword = userPassword;
		this.userPasswordTip = userPasswordTip;
	}
	/**
	 * @return the userName
	 */
	public String getUserName() {
		return userName;
	}
	/**
	 * @return the userPassword
	 */
	public String getUserPassword() {
		return userPassword;
	}
	/**
	 * @return the userPasswordTip
	 */
	public String getUserPasswordTip() {
		return userPasswordTip;
	}
	/**
	 * @param userName the userName to set
	 */
	public void setUserName(String userName) {
		this.userName = userName;
	}
	/**
	 * @param userPassword the userPassword to set
	 */
	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}
	/**
	 * @param userPasswordTip the userPasswordTip to set
	 */
	public void setUserPasswordTip(String userPasswordTip) {
		this.userPasswordTip = userPasswordTip;
	}
	@Override
	public String toValue() {
		return " " 
				+ "\'"
				+ this.getUserName() + "\'" + ", " + "\'"
				+ this.getUserPassword() + "\'" + ", " + "\'"
				+ this.getUserPasswordTip() + "\'"
				+ " ";
	}
	@Override
	public String toName() {
		return " "
				+ "userName " + ", "
				+ "userPassword" + ", "
				+ "userPasswordTip"
				+ " ";
	}
	@Override
	public String toTableName() {
		return "userlogdata";
	}
	@Override
	public String toPrimaryKeyName() {
		return " userName"
				+ " " ;
	}
	@Override
	public String toPrimaryKeyValue() {
		return " " 
				+ "\'"
				+ this.getUserName() + "\'";
	}
	@Override
	public String toAttributes() {
		return " "
				+ "userName char(25) primary key, "
				+ "userPassword char( 25), "
				+ "userPasswordTip char(50), "
//				+ "primary key ( userName, userPassword)"
				+ " ";
	}
	@Override
	public String toString() {
		return "user {name: " + this.getUserName() 
				+ ", password: " + this.getUserPassword()
				+ ", tip: " + this.getUserPasswordTip();
	}
}
