package com.mrli.prepar.to.export.jar;

public class JEBDOperator {

}
