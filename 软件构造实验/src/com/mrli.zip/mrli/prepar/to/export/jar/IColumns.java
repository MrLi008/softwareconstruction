/**
 * 
 */
package com.mrli.prepar.to.export.jar;

/**
 * @author MrLi
 *
 */
public interface IColumns {

}
