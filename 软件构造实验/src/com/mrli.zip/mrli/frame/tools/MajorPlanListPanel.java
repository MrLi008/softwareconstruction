package com.mrli.frame.tools;

import javax.swing.JPanel;

public class MajorPlanListPanel extends JPanel {

	/**
	 * Create the panel.
	 */
	public MajorPlanListPanel() {

	}

}
